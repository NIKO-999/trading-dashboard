/* Obsidian vault connection — File System Access API */

export async function connectVault() {
  if (typeof window.showDirectoryPicker !== 'function') {
    return { ok: false, message: 'Folder access needs Chrome/Edge/Arc/Brave on a computer.' };
  }
  if (window.self !== window.top) {
    return { ok: false, message: 'Open Mission Control in its own tab to connect (picker blocked in preview).' };
  }
  try {
    const dir = await window.showDirectoryPicker({ id: 'mc-vault', mode: 'read' });
    const files = [];
    await walk(dir, '', files);
    files.sort((a, b) => a.path.localeCompare(b.path));
    return { ok: true, message: `Connected — ${files.length} notes in "${dir.name}"`, files };
  } catch (e) {
    if (e && e.name === 'AbortError') return { ok: false, message: 'No folder selected.' };
    return { ok: false, message: 'Could not open that folder.' };
  }
}

async function walk(dir, path, out) {
  for await (const [name, handle] of dir.entries()) {
    if (handle.kind === 'directory') {
      if (name.startsWith('.') || name === 'node_modules') continue;
      await walk(handle, path ? `${path}/${name}` : name, out);
    } else if (name.toLowerCase().endsWith('.md')) {
      out.push({ name: name.replace(/\.md$/i, ''), path: path ? `${path}/${name}` : name, folder: path });
    }
  }
}

export function renderVaultTree(container, files) {
  container.innerHTML = '';
  if (!files.length) {
    container.innerHTML = '<div class="view-note mono">No markdown notes found.</div>';
    return;
  }
  for (const f of files.slice(0, 200)) {
    const el = document.createElement('div');
    el.className = 'vault-file';
    el.innerHTML = `<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M14 3H7a1 1 0 0 0-1 1v16a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1V8z"/><path d="M14 3v5h5"/></svg><span>${f.name}</span>`;
    if (f.folder) {
      const tag = document.createElement('span');
      tag.style.cssText = 'margin-left:auto;font-size:9.5px;color:var(--txt-faint)';
      tag.textContent = f.folder;
      el.appendChild(tag);
    }
    container.appendChild(el);
  }
}
