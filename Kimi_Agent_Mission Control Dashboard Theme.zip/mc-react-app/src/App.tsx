import { useEffect, useMemo, useState, type ComponentType } from 'react';
import {
  ArrowLeft,
  Home,
  BookOpen,
  CalendarDays,
  Database,
  Download,
  LayoutGrid,
  Library,
  List,
  Plus,
  Trash2,
  Upload,
} from 'lucide-react';
import { Ambient } from './components/Ambient';
import { Toasts } from './components/Toasts';
import { Modal, ModalHead } from './components/kit';
import { DashboardPage } from './pages/DashboardPage';
import { DayViewPage } from './pages/DayViewPage';
import Journal from './pages/Journal';
import { TradesPage } from './pages/TradesPage';
import { ImportPage } from './pages/ImportPage';
import { KnowledgeBase } from './pages/KnowledgeBase';
import { clearAll, exportJson, importJson, pushToast, useStore } from './store/useStore';
import { gradedEntries } from './utils/analytics';

type Page = 'dashboard' | 'dayview' | 'journal' | 'trades' | 'import' | 'knowledge';

type JournalIntent = { kind: 'new' } | { kind: 'focus'; id: string } | null;

const NAV: { id: Page; label: string; icon: ComponentType<{ size?: number }> }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutGrid },
  { id: 'dayview', label: 'Day View', icon: CalendarDays },
  { id: 'journal', label: 'Journal', icon: BookOpen },
  { id: 'trades', label: 'Trades', icon: List },
  { id: 'import', label: 'Import', icon: Upload },
];

const PAGE_META: Record<Page, { eyebrow: string; title: string }> = {
  dashboard: { eyebrow: 'Session overview', title: 'Dashboard' },
  dayview: { eyebrow: 'Day by day', title: 'Day View' },
  journal: { eyebrow: 'Calendar & entries', title: 'Journal' },
  trades: { eyebrow: 'Full ledger', title: 'Trades' },
  import: { eyebrow: 'Bring your history', title: 'Import' },
  knowledge: { eyebrow: 'Your vault', title: 'Knowledge Base' },
};

/** which pages belong to the Trading section — new sections add their own set */
const TRADING_PAGES = new Set<Page>(NAV.map((n) => n.id));

function withinTimeframe(entries: ReturnType<typeof gradedEntries>, days: number | null) {
  if (days == null) return entries;
  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - days);
  const cutoffStr = cutoff.toISOString().slice(0, 10);
  return entries.filter((e) => e.date >= cutoffStr);
}

export default function App() {
  const data = useStore();
  const [page, setPage] = useState<Page>(() => (window.location.hash === '#knowledge' ? 'knowledge' : 'dashboard'));
  const [timeframeDays, setTimeframeDays] = useState<number | null>(null);
  const [journalIntent, setJournalIntent] = useState<JournalIntent>(null);
  const [dataModal, setDataModal] = useState(false);

  function navigate(next: Page) {
    setPage(next);
    window.location.hash = next === 'knowledge' ? 'knowledge' : '';
  }

  const allGraded = useMemo(
    () => gradedEntries(data.entries, false),
    [data.entries],
  );
  const entries = useMemo(() => withinTimeframe(allGraded, timeframeDays), [allGraded, timeframeDays]);

  function openJournal() {
    navigate('journal');
  }

  function openTrade(id: string) {
    setPage('journal');
    setJournalIntent({ kind: 'focus', id });
  }

  function logTrade() {
    setPage('journal');
    setJournalIntent({ kind: 'new' });
  }

  const meta = PAGE_META[page];
  const inTrading = TRADING_PAGES.has(page); // sections are self-contained — no cross-section chrome

  return (
    <>
      <Ambient />
      <div
        className="mc-stage"
        style={{
          position: 'relative',
          zIndex: 2,
          height: '100vh',
          padding: '22px 26px',
          display: 'grid',
          gridTemplateColumns: '64px 1fr',
          gap: 20,
        }}
      >
        {/* ---------- icon rail (desktop only — mobile navigates via the panel) ---------- */}
        <nav className="mc-rail">
          <a
            className="mc-rail-btn"
            title="Back to Hub"
            href="../index.html"
            style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', textDecoration: 'none', color: 'inherit' }}
          >
            <Home size={18} />
          </a>
          <div style={{ height: 1, width: 26, background: 'var(--hairline-soft)', margin: '2px 0' }} />
          {NAV.map((item) => (
            <button
              key={item.id}
              className={`mc-rail-btn ${page === item.id ? 'active' : ''}`}
              title={item.label}
              onClick={() => navigate(item.id)}
            >
              <item.icon size={18} />
            </button>
          ))}
          <div style={{ flex: 1 }} />
          <div className="mc-rail-divider-wide" style={{ height: 1, width: 26, background: 'var(--hairline-soft)', margin: '2px 0' }} />
          {/* other sections — trading stays grouped above; each new section adds one button here */}
          <button
            className={`mc-rail-btn ${page === 'knowledge' ? 'active' : ''}`}
            title="Knowledge Base"
            onClick={() => navigate('knowledge')}
          >
            <Library size={18} />
          </button>
          <div style={{ flex: 1 }} />
          <div className="mc-rail-label">Mission Control</div>
          <button className="mc-rail-btn" title="Data & backups" onClick={() => setDataModal(true)}>
            <Database size={18} />
          </button>
        </nav>

        {/* ---------- main ---------- */}
        <main style={{ display: 'flex', flexDirection: 'column', gap: 18, minWidth: 0, minHeight: 0 }}>
          <div className="mc-topbar" style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', padding: '4px 6px 0', flexShrink: 0 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
              {page !== 'dashboard' && inTrading && (
                <button
                  className="mc-icon-btn"
                  style={{ width: 38, height: 38, borderRadius: 13, background: 'var(--glass-strong)', border: '1px solid var(--hairline-soft)' }}
                  title="Back to Dashboard"
                  onClick={() => navigate('dashboard')}
                >
                  <ArrowLeft size={16} />
                </button>
              )}
              <div>
                <div className="mc-eyebrow">
                  <span className="mc-live-dot" />
                  {meta.eyebrow}
                </div>
                <h1 className="mc-h1" style={{ margin: '6px 0 0' }}>
                  {meta.title}
                </h1>
              </div>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 24 }}>
              {inTrading && (
                <button className="mc-btn primary" onClick={logTrade}>
                  <Plus size={14} />
                  Log Trade
                </button>
              )}
              <div className="mc-topbar-clock">
                <Clock />
              </div>
            </div>
          </div>

          <div className="mc-main-scroll" style={{ flex: 1, minHeight: 0, overflowY: 'auto', paddingRight: 4, paddingBottom: 10, display: 'flex', flexDirection: 'column' }}>
            {page === 'dashboard' && (
              <DashboardPage
                entries={entries}
                allGradedCount={allGraded.length}
                timeframeDays={timeframeDays}
                onTimeframeChange={setTimeframeDays}
                onOpenJournal={openJournal}
                onOpenTrade={openTrade}
              />
            )}
            {page === 'dayview' && <DayViewPage entries={entries} onOpenTrade={openTrade} />}
            {page === 'journal' && <Journal focusId={journalIntent?.kind === 'focus' ? journalIntent.id : null} onFocusConsumed={() => setJournalIntent(null)} newEntryRequested={journalIntent?.kind === 'new'} onNewEntryConsumed={() => setJournalIntent(null)} />}
            {page === 'trades' && <TradesPage entries={entries} onOpenTrade={openTrade} />}
            {page === 'import' && <ImportPage />}
            {page === 'knowledge' && <KnowledgeBase />}
          </div>
        </main>
      </div>

      {dataModal && <DataModal onClose={() => setDataModal(false)} />}
      <Toasts />
    </>
  );
}

/* ---------- live session clock ---------- */

function Clock() {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const iv = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(iv);
  }, []);
  const p = (n: number) => String(n).padStart(2, '0');
  return (
    <div style={{ textAlign: 'right' }}>
      <div className="mc-num-thin" style={{ fontSize: 22, letterSpacing: 1 }}>
        {p(now.getHours())}:{p(now.getMinutes())}:{p(now.getSeconds())}
      </div>
      <div style={{ fontSize: 10, letterSpacing: 2, textTransform: 'uppercase', color: 'var(--txt-faint)', marginTop: 3 }}>
        {now.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
      </div>
    </div>
  );
}

/* ---------- data & backups ---------- */

function DataModal({ onClose }: { onClose: () => void }) {
  const data = useStore();
  const [confirmWipe, setConfirmWipe] = useState(false);

  function doExport() {
    const blob = new Blob([exportJson()], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `mission-control-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    pushToast('Backup downloaded');
  }

  function doImport(file: File) {
    file.text().then((text) => {
      if (importJson(text)) {
        pushToast('Backup restored');
        onClose();
      } else {
        pushToast('That file is not a valid Mission Control backup');
      }
    });
  }

  return (
    <Modal onClose={onClose} width={440}>
      <ModalHead title="Data & backups" onClose={onClose} />
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        <div style={{ fontSize: 11.5, color: 'var(--txt-faint)', lineHeight: 1.65 }}>
          Everything lives in this browser's local storage — {data.entries.length} entries right now. Export a backup
          before switching browsers or clearing site data.
        </div>
        <button className="mc-btn" onClick={doExport}>
          <Download size={13} /> Export backup (.json)
        </button>
        <label className="mc-btn" style={{ justifyContent: 'center', cursor: 'pointer' }}>
          <Upload size={13} /> Restore from backup
          <input
            type="file"
            accept=".json,application/json"
            hidden
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) doImport(f);
              e.target.value = '';
            }}
          />
        </label>
        <div style={{ borderTop: '1px solid var(--hairline-soft)', margin: '6px 0' }} />
        {!confirmWipe ? (
          <button className="mc-btn danger" onClick={() => setConfirmWipe(true)}>
            <Trash2 size={13} /> Clear all data…
          </button>
        ) : (
          <button
            className="mc-btn danger"
            onClick={() => {
              clearAll();
              pushToast('All data cleared');
              onClose();
            }}
          >
            <Trash2 size={13} /> Really erase everything — no undo
          </button>
        )}
      </div>
    </Modal>
  );
}
