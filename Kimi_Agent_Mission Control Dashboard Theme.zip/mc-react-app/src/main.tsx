import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router'
import '@fontsource/inter/200.css'
import '@fontsource/inter/300.css'
import '@fontsource/inter/400.css'
import '@fontsource/inter/500.css'
import '@fontsource/inter/600.css'
import '@fontsource/inter/700.css'
import './index.css'
import App from './App.tsx'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </StrictMode>,
)

// Slow reveal: the frosted veil holds while the app mounts, then fades out
// gradually. Opacity is driven per-frame so it animates smoothly on mobile.
requestAnimationFrame(() => {
  setTimeout(() => {
    const veil = document.getElementById('veil');
    if (!veil) return;
    const DURATION = 1700;
    const start = performance.now();
    const tick = (now: number) => {
      const t = Math.min((now - start) / DURATION, 1);
      const e = 1 - Math.pow(1 - t, 3); // cubic ease-out
      veil.style.opacity = String(1 - e);
      if (t < 1) requestAnimationFrame(tick);
      else veil.remove();
    };
    requestAnimationFrame(tick);
  }, 400);
})
